package com.classroom;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.classroom.model.Leave;
import com.classroom.repositiory.LeaveRepository;

@SpringBootTest
class testLeaves {

	@Autowired
	private LeaveRepository leaveRepository;

	@Test
	void test() {
		List<Leave> list = leaveRepository.getByTeacherAndStatusAndLeavetypeAndMonth(1001, true, "sick");
		System.out.println(list.size());
	}

}

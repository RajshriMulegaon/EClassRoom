package com.classroom;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.classroom.model.Standard;
import com.classroom.model.Subject;
import com.classroom.service.StandardService;
import com.classroom.service.SubjectService;

@SpringBootTest
class testStandard {

	@Autowired
	private StandardService standardService;
	@Autowired
	private SubjectService subjectService;

	@Test
	@Disabled
	void addResult() {
		assertNotNull(standardService.saveStandard(new Standard(0, "Std", null)));
	}

	@Test
//	@Disabled
	void addSubject() {
		Standard standardById = standardService.getStandardById(101);

		assertNotNull(subjectService.addSubject(new Subject(1, "Sub1"), standardById));
	}
}

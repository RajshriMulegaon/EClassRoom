package com.classroom.service;

import java.util.List;

import com.classroom.model.Standard;
import com.classroom.model.Subject;

public interface StandardService {

	List<Standard> getAllStandards();

	public Standard saveStandard(Standard standard);

	public boolean deleteStandard(int id);

	public Subject updateStandard(int id, Subject subject);

	public Standard getStandardById(int id);

	public Standard findStandardByName(String standardName);

	List<Subject> getSubjectsByStandard(int id);

	Standard savesStandard(Standard standard);
}
package com.classroom.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "Quiz")
public class Quiz {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "quiz_sequence")
	@SequenceGenerator(name = "quiz_sequence", sequenceName = "quiz_sequence", allocationSize = 1, initialValue = 10)
	@Column(name = "QuizId")
	private int qId;

	@Column(length = 50)
	private String title;

	@Column(length = 5)
	private String maxMarks;
	@Column(length = 5)
	private String numberOfQuestions;
	@Column(length = 50)
	private String subject;

	private Date date;
	@Column(length = 5)
	private String teacherId;
	@Column(length = 50)

	private String standard;
	@OneToMany(mappedBy = "quiz", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonIgnore
	private Set<Question> questions = new HashSet<>();
	
//	@Column(name = "request_approved")
//	private boolean requestApproved = false;
//
//	public boolean isRequestApproved() {
//		return requestApproved;
//	}
//
//	public void setRequestApproved(boolean requestApproved) {
//		this.requestApproved = requestApproved;
//	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}

	public boolean isActive() {
		return active;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	private boolean active = true;

	public Quiz() {
	}

	public int getqId() {
		return qId;
	}

	public void setqId(int qId) {
		this.qId = qId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMaxMarks() {
		return maxMarks;
	}

	public void setMaxMarks(String maxMarks) {
		this.maxMarks = maxMarks;
	}

	public String getNumberOfQuestions() {
		return numberOfQuestions;
	}

	public void setNumberOfQuestions(String numberOfQuestions) {
		this.numberOfQuestions = numberOfQuestions;
	}

	public Set<Question> getQuestions() {
		return questions;
	}

	public void setQuestions(Set<Question> questions) {
		this.questions = questions;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	@Override
	public String toString() {
		return "Quiz [qId=" + qId + ", title=" + title + ", maxMarks=" + maxMarks + ", numberOfQuestions="
				+ numberOfQuestions + ", subject=" + subject + ", date=" + date + ", teacherId=" + teacherId
				+ ", standard=" + standard + ", questions=" + questions + ", active=" + active + "]";
	}

}

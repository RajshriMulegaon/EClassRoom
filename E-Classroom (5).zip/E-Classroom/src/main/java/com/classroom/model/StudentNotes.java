package com.classroom.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "students_notes")
public class StudentNotes {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "stud_note_sequence")
	@SequenceGenerator(name = "stud_note_sequence", sequenceName = "stud_note_sequence", allocationSize = 1, initialValue = 10)
	@Column(name = "stud_note_id")
	private int id;

	@Column(columnDefinition = "LONGBLOB")
	private byte[] note;

	@Column(name = "title")
	private String title;

	@Column(length = 50)
	private String fileName;

	@Temporal(TemporalType.DATE)
	private Date date;

	@Transient
	private String standard;
	@Transient
	private String subject;

	@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER)
	private Subject subjects;
	@JsonIgnore
	@ManyToOne(fetch = FetchType.EAGER)
	private Standard standards;

	public StudentNotes() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public byte[] getNote() {
		return note;
	}

	public void setNote(byte[] note) {
		this.note = note;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Subject getSubjects() {
		return subjects;
	}

	public void setSubjects(Subject subjects) {
		this.subjects = subjects;
	}

	public Standard getStandards() {
		return standards;
	}

	public void setStandards(Standard standards) {
		this.standards = standards;
	}

}

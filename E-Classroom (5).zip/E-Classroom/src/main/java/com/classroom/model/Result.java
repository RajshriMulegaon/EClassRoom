package com.classroom.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Result")
public class Result {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "result_sequence")
	@SequenceGenerator(name = "result_sequence", sequenceName = "result_sequence", allocationSize = 1, initialValue = 500)
	private int rid;
	@Column(name = "obtained_marks")
	private int marks;
	@Column(name = "max_marks")
	private int maxmarks;
	private int studentId;
	@Column(length = 50)
	private String subject;
	@Column(name = "student_name", length = 50)
	private String name;
	@Temporal(TemporalType.DATE)
	private Date date;
	@Column(length = 50)
	private String title;

	@Column(length = 50)
	private String standard;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Result() {

	}

	public Result(int marks, int studentId, String subject) {
		super();
		this.marks = marks;
		this.studentId = studentId;
		this.subject = subject;
	}

	public int getMaxmarks() {
		return maxmarks;
	}

	public void setMaxmarks(int maxmarks) {
		this.maxmarks = maxmarks;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRid() {
		return rid;
	}

	public void setRid(int rid) {
		this.rid = rid;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	@Override
	public String toString() {
		return "Result [rid=" + rid + ", marks=" + marks + ", maxmarks=" + maxmarks + ", studentId=" + studentId
				+ ", subject=" + subject + ", name=" + name + "]";
	}

}

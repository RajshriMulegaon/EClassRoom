package com.classroom.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.classroom.model.Notes;
import com.classroom.model.StudentNotes;
import com.classroom.service.NotesService;
import com.classroom.service.StudentNotesService;

@RestController
@RequestMapping("/notes")
@CrossOrigin("*")
public class NotesController {
	@Autowired
	private NotesService noteservice;

	@Autowired
	private StudentNotesService studentNotesService;

	List<String> files = new ArrayList<String>();

	@PostMapping("/savefile")
	public ResponseEntity<?> handleFileUpload(@RequestParam("noteFile") MultipartFile noteFile,
			@RequestParam("noteTitle") String noteTitle, @RequestParam("standard") String standard,
			@RequestParam("subject") String subject) throws IOException {

		Object obj = noteservice.addNotesServiceFun(noteFile, noteTitle, standard, subject);
		if (obj instanceof Notes) {
			return new ResponseEntity<Notes>((Notes) obj, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<String>(HttpStatus.CONFLICT);
		}
	}

	@GetMapping("/get")
	public List<StudentNotes> getAllNotes() {
//		System.out.println("get all  notes");
		return studentNotesService.getAllNotes();
	}

	@GetMapping("/get/std/{std}")
	public List<StudentNotes> getNotesByStandard(@PathVariable String std) {
//		System.out.println("get all  notes");
		return studentNotesService.getStandardNotes(std);
	}

	@GetMapping("/get/byid/{id}")
	public List<Notes> getNotesByTeacherId(@PathVariable String id) {
//		System.out.println("get all  notes");
		return noteservice.getNotesByTeacherId(id);
	}

	@GetMapping("/student/get")
	public List<StudentNotes> getAllStudentsNotes() {
//		System.out.println("get all  notes");
		return studentNotesService.getAllNotes();
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<Notes> updateUser(@PathVariable int id, @Validated @RequestBody Notes notes) {
		notes.setId(id);
		return new ResponseEntity<Notes>(noteservice.update(notes), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteNotes(@PathVariable int id) {
//		System.out.println(id);
		noteservice.deleteNotes(id);
	}

	@DeleteMapping("/delete/stud/{id}")
	public void deleteStudentNotes(@PathVariable int id) {
//		System.out.println(id);
		noteservice.deleteStudentNotes(id);
	}

	@GetMapping(path = "/gets/{id}")
	public ResponseEntity<Resource> downloaded(@PathVariable int id) throws IOException {

		Notes notes = noteservice.getNoteById(id).get();

		ByteArrayResource resource = new ByteArrayResource(notes.getNote());

		return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/pdf")).body(resource);
	}

	@GetMapping(path = "/getstud/{id}")
	public ResponseEntity<Resource> downloadForStudent(@PathVariable int id) throws IOException {

		StudentNotes notes = studentNotesService.getUserById(id).get();

		ByteArrayResource resource = new ByteArrayResource(notes.getNote());

		return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/pdf")).body(resource);
	}

	@GetMapping(path = "/get/{id}")
	public ResponseEntity<Resource> download(@PathVariable int id) throws IOException {

		Notes notes = noteservice.getNoteById(id).get();

		ByteArrayResource resource = new ByteArrayResource(notes.getNote());

		return ResponseEntity.ok().headers(this.headers(notes.getTitle())).contentLength(resource.contentLength())
				.contentType(MediaType.parseMediaType("application/pdf")).body(resource);
	}

	@GetMapping(path = "/get/stud/{id}")
	public ResponseEntity<Resource> downloadFile(@PathVariable int id) throws IOException {

		StudentNotes notes = studentNotesService.getUserById(id).get();

		ByteArrayResource resource = new ByteArrayResource(notes.getNote());

		return ResponseEntity.ok().headers(this.headers(notes.getTitle())).contentLength(resource.contentLength())
				.contentType(MediaType.parseMediaType("application/pdf")).body(resource);
	}

	private HttpHeaders headers(String name) {

		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + name + ".pdf");
		header.add("Cache-Control", "no-cache, no-store, must-revalidate");
		header.add("Pragma", "no-cache");
		header.add("Expires", "0");
		return header;
	}

}
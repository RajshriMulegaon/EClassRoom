package com.classroom.repositiory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.Subject;

public interface SubjectRepo extends JpaRepository<Subject, Integer> {

	Subject findBySname(String subjectName);

//	List<Subject> findByStandard(Standard standard);
// public List<Subject> findBySubjectName(String s);     
}
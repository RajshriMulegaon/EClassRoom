package com.classroom.repositiory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.UserHistory;

public interface UserHistoryRepo extends JpaRepository<UserHistory, Integer> {

}

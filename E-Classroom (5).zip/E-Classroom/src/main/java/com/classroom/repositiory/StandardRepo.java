package com.classroom.repositiory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.classroom.model.Standard;

public interface StandardRepo extends JpaRepository<Standard, Integer> {
	Standard findByName(String name);

}
